package com.example.dattespretige;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PrAdapter extends RecyclerView.Adapter<PrAdapter.HolderPrepration> {

    private Context context;
    public ArrayList<commande> list,filterList;

    public PrAdapter(Context context, ArrayList<commande> list) {
        this.context = context;
        this.list = list;
        this.filterList = list;
    }

    @NonNull
    @Override
    public HolderPrepration onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.hoderpreparation, parent, false);
        return new HolderPrepration(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderPrepration holder, int position) {
        //get data
        String name, café, Truffe, Pistache, Noix_de_coco, Speculos, Caramel_beurre_salé, praliné,
                Amande_gout_rose, Amande_gout_orange, Citron,
                Gingember_citron_Vert, framboise, caramel_chocolate,
                amande_Rose, Amande_Orange, Amande_gingembre, Amande_kaab_ghzal, Pistache_beldi;
        commande com = list.get(position);
        name = com.getName();
        café = com.getCafé();
        Truffe = com.getTruffe();
        Pistache = com.getPistache();
        Noix_de_coco = com.getNoix_de_coco();
        Speculos = com.getSpeculos();
        caramel_chocolate = com.getCaramel_chocolate();
        praliné = com.getPraliné();
        Amande_gout_rose = com.getAmande_gout_rose();
        Amande_gout_orange = com.getAmande_gout_orange();
        Citron = com.getCitron();
        Gingember_citron_Vert = com.getGingember_citron_Vert();
        framboise = com.getFramboise();
        Caramel_beurre_salé = com.getCaramel_beurre_salé();
        amande_Rose = com.getAmande_Rose();
        Amande_Orange = com.getAmande_Orange();
        Amande_gingembre = com.getAmande_gingembre();
        Amande_kaab_ghzal = com.getAmande_kaab_ghzal();
        Pistache_beldi = com.getPistache_beldi();
        //set data
        holder.nametv.setText(name);
        holder.cafétv.setText(café);
        holder.Truffetv.setText(Truffe);
        holder.Pistachetv.setText(Pistache);
        holder.Noix_de_cocotv.setText(Noix_de_coco);
        holder.Speculostv.setText(Speculos);
        holder.caramel_chocolatetv.setText(caramel_chocolate);
        holder.pralinétv.setText(praliné);
        holder.Amande_gout_rosetv.setText(Amande_gout_rose);
        holder.Amande_gout_orangetv.setText(Amande_gout_orange);
        holder.Citrontv.setText(Citron);
        holder.Gingember_citron_Verttv.setText(Gingember_citron_Vert);
        holder.framboisetv.setText(framboise);
        holder.Caramel_beurre_salétv.setText(Caramel_beurre_salé);
        holder.amande_Rosetv.setText(amande_Rose);
        holder.Amande_Orangetv.setText(Amande_Orange);
        holder.Amande_gingembretv.setText(Amande_gingembre);
        holder.Amande_kaab_ghzaltv.setText(Amande_kaab_ghzal);
        holder.Pistache_belditv.setText(Pistache_beldi);


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class HolderPrepration extends RecyclerView.ViewHolder {
        TextView nametv, cafétv, Truffetv, Pistachetv, Noix_de_cocotv, Speculostv, Caramel_beurre_salétv, pralinétv,
                Amande_gout_rosetv, Amande_gout_orangetv, Citrontv,
                Gingember_citron_Verttv, framboisetv, caramel_chocolatetv,
                amande_Rosetv, Amande_Orangetv, Amande_gingembretv, Amande_kaab_ghzaltv, Pistache_belditv;

        public HolderPrepration(@NonNull View itemView) {
            super(itemView);
            nametv = itemView.findViewById(R.id.textViewCol1);
            cafétv = itemView.findViewById(R.id.textViewCol2);
            Truffetv = itemView.findViewById(R.id.textViewCol3);
            Pistachetv = itemView.findViewById(R.id.textViewCol4);
            Noix_de_cocotv = itemView.findViewById(R.id.textViewCol5);
            Speculostv = itemView.findViewById(R.id.textViewCol6);
            Caramel_beurre_salétv = itemView.findViewById(R.id.textViewCol7);
            pralinétv = itemView.findViewById(R.id.textViewCol8);
            Amande_gout_rosetv = itemView.findViewById(R.id.textViewCol9);
            Amande_gout_orangetv = itemView.findViewById(R.id.textViewCol10);
            Citrontv = itemView.findViewById(R.id.textViewCol11);
            Gingember_citron_Verttv = itemView.findViewById(R.id.textViewCol12);
            framboisetv = itemView.findViewById(R.id.textViewCol13);
            caramel_chocolatetv = itemView.findViewById(R.id.textViewCol14);
            amande_Rosetv = itemView.findViewById(R.id.textViewCol15);
            Amande_Orangetv = itemView.findViewById(R.id.textViewCol16);
            Amande_gingembretv = itemView.findViewById(R.id.textViewCol17);
            Amande_kaab_ghzaltv = itemView.findViewById(R.id.textViewCol18);
            Pistache_belditv = itemView.findViewById(R.id.textViewCol19);


        }
    }
}
