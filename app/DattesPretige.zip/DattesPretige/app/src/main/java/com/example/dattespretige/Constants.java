package com.example.dattespretige;

public class Constants {
    public static final String[] commandeStatus = {
            "Showing All Order",
            "en cours",
            "terminer",
            "Annulé",
            "En attente"

    };





}
