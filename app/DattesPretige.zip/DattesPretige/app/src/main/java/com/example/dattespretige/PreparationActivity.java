package com.example.dattespretige;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

public class PreparationActivity extends AppCompatActivity {
    TextView textView, textView2;
    TableLayout table_layout;
    private ArrayList<commande> commandesaprepa;
    PrAdapter adapter;
    RecyclerView recyclerViewprep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preparation);
        recyclerViewprep = findViewById(R.id.rvadapter);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerViewprep.setLayoutManager(layoutManager);
        recyclerViewprep.setAdapter(adapter);

        loadPrarationdata("en cours");

    }

    private void loadPrarationdata(String selected) {
        commandesaprepa = new ArrayList<>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference(commande.class.getSimpleName());
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        commandesaprepa.clear();
                        for (DataSnapshot ds:dataSnapshot.getChildren()){
                            String commandestatus = ""+ds.child("status").getValue();
                            if (selected.equals(commandestatus)){
                                commande com = ds.getValue(commande.class);
                                commandesaprepa.add(com);
                            }

                        }
                        adapter =new PrAdapter(PreparationActivity.this,commandesaprepa);
                        recyclerViewprep.setAdapter(adapter);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                    }
                });

    }

}