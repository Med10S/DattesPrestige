package com.example.dattespretige;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class EditCommandeActivity2 extends AppCompatActivity {
    private String ComId,uid;
    private String SelectedProduct;//to hold the value of selected product
    private String status;

    public Spinner ProductSpinner,statuset;
    private ProgressDialog progressDialog;
    public ArrayAdapter<CharSequence> ProductAdapter,statusAdapter;
    public TextInputEditText nameET, addresset, phoneet, timeet;
    //declaration des saveurs
    public EditText detailet, priceet;
    public EditText Pralinéet,
            caféet,
            Caramel_beurre_saléet,
            Truffeet, Pistacheet, Noix_de_cocoet, Speculoset,
            Amande_gout_roseet, Amande_gout_orangeet, Citronet,
            Gingember_citron_Vertet, framboiseet, caramel_chocolateet,
            amande_Roseet, Amande_Orangeet, Amande_gingembreet, Amande_kaab_ghzalet, Pistache_beldiet;
    public TextView total_tvet;
    public AppCompatButton editbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_commande2);
        ComId = getIntent().getStringExtra("ComId");
        uid = getIntent().getStringExtra("uid");
        //spinner status
        statuset = findViewById(R.id.statuset);
        statusAdapter =ArrayAdapter.createFromResource(this, R.array.status_commande, R.layout.spinner_layout);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statuset.setPrompt("Etat de la commande : ");
        statuset.setAdapter(statusAdapter);
        statuset.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                status=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

//product spinner
        ProductSpinner = findViewById(R.id.spinnerProduct);
        ProductAdapter = ArrayAdapter.createFromResource(this, R.array.array_Product, R.layout.spinner_layout);

        ProductAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ProductSpinner.setAdapter(ProductAdapter);
        ProductSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SelectedProduct = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        nameET = findViewById(R.id.textInputName);
        addresset = findViewById(R.id.textInputAddress);
        phoneet = findViewById(R.id.textInputphone);
        timeet = findViewById(R.id.textInputTime);
        priceet = findViewById(R.id.price_text);
        timeet.setInputType(InputType.TYPE_NULL);
        timeet.setOnClickListener(v -> {
            showDateTimeDialog(timeet);
        });
        detailet = findViewById(R.id.details);
        editbtn = findViewById(R.id.updatebtn);
        total_tvet = findViewById(R.id.total);
        //initialisation des saveurs
        Pralinéet = findViewById(R.id.Praliné_val);
        caféet = findViewById(R.id.Cafe_val);
        Caramel_beurre_saléet = findViewById(R.id.Caramel_beurre_salé_val);
        Pistacheet = findViewById(R.id.Pistache_val);
        Noix_de_cocoet = findViewById(R.id.Noix_de_coco_val);
        Speculoset = findViewById(R.id.Speculos_val);
        Amande_gout_roseet = findViewById(R.id.Amande_gout_rose_val);
        Citronet = findViewById(R.id.Citron_val);
        Gingember_citron_Vertet = findViewById(R.id.Gingember_citron_Vert_val);
        framboiseet = findViewById(R.id.framboise_val);
        caramel_chocolateet = findViewById(R.id.caramel_chocolate_val);
        amande_Roseet = findViewById(R.id.amande_Rose_val);
        Amande_Orangeet = findViewById(R.id.Amande_Orange_val);
        Amande_gingembreet = findViewById(R.id.Amande_gingembre_val);
        Amande_kaab_ghzalet = findViewById(R.id.Amande_kaab_ghzal_val);
        Pistache_beldiet = findViewById(R.id.Pistache_beldi_val);
        Amande_gout_orangeet = findViewById(R.id.Amande_gout_orange_val);
        Truffeet = findViewById(R.id.Truffe_val);


        loadCommandeDetails();
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("please wait");
        progressDialog.setCanceledOnTouchOutside(false);



        editbtn.setOnClickListener(v -> {
            inputData();
        });



    }
    private void loadCommandeDetails() {
        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("commande");
        reference1.
                child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String id = "" + snapshot.child("id").getValue();
                        String name = "" + snapshot.child("name").getValue();
                        String address = "" + snapshot.child("address").getValue();
                        String phone = "" + snapshot.child("phone").getValue();
                        String time = "" + snapshot.child("time").getValue();
                        String product = "" + snapshot.child("product").getValue();
                        String details = "" + snapshot.child("details").getValue();
                        String status = "" + snapshot.child("status").getValue();
                        String price = "" + snapshot.child("price").getValue();
                        String café = "" + snapshot.child("café").getValue();
                        String praliné = "" + snapshot.child("praliné").getValue();
                        String Caramel_beurre_salé = "" + snapshot.child("Caramel_beurre_salé").getValue();
                        String Pistache = "" + snapshot.child("Pistache").getValue();
                        String Noix_de_coco = "" + snapshot.child("Noix_de_coco").getValue();
                        String Speculos = "" + snapshot.child("Speculos").getValue();
                        String Amande_gout_rose = "" + snapshot.child("Amande_gout_rose").getValue();
                        String Citron = "" + snapshot.child("Citron").getValue();
                        String Gingember_citron_Vert = "" + snapshot.child("Gingember_citron_Vert").getValue();
                        String framboise = "" + snapshot.child("framboise").getValue();
                        String caramel_chocolate = "" + snapshot.child("caramel_chocolate").getValue();
                        String amande_Rose = "" + snapshot.child("amande_Rose").getValue();
                        String Amande_Orange = "" + snapshot.child("Amande_Orange").getValue();
                        String Amande_gingembre = "" + snapshot.child("Amande_gingembre").getValue();
                        String Amande_kaab_ghzal = "" + snapshot.child("Amande_kaab_ghzal").getValue();
                        String Pistache_beldi = "" + snapshot.child("Pistache_beldi").getValue();
                        String Amande_gout_orange = "" + snapshot.child("Amande_gout_orange").getValue();
                        String Truffe = "" + snapshot.child("Truffe").getValue();

                        nameET.setText(name);
                        addresset.setText(address);
                        phoneet.setText(phone);
                        timeet.setText(time);

                        int spinnerPosition = ProductAdapter.getPosition(product);
                        ProductSpinner.setSelection(spinnerPosition);

                        int spinnerPosition2 = statusAdapter.getPosition(status);
                        statuset.setSelection(spinnerPosition2);


                        detailet.setText(details);
                        //statuset.setText(status);
                        priceet.setText(price);
                        caféet.setText(café);
                        Caramel_beurre_saléet.setText(Caramel_beurre_salé);
                        Pistacheet.setText(Pistache);
                        Noix_de_cocoet.setText(Noix_de_coco);
                        Speculoset.setText(Speculos);
                        Amande_gout_roseet.setText(Amande_gout_rose);
                        Pralinéet.setText(praliné);
                        Citronet.setText(Citron);
                        Gingember_citron_Vertet.setText(Gingember_citron_Vert);
                        framboiseet.setText(framboise);
                        caramel_chocolateet.setText(caramel_chocolate);
                        amande_Roseet.setText(amande_Rose);
                        Amande_Orangeet.setText(Amande_Orange);
                        Amande_gingembreet.setText(Amande_gingembre);
                        Amande_kaab_ghzalet.setText(Amande_kaab_ghzal);
                        Pistache_beldiet.setText(Pistache_beldi);
                        Amande_gout_orangeet.setText(Amande_gout_orange);
                        Truffeet.setText(Truffe);


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private String Dname, Daddress, Dphone, Dtime, Ddetail, Dprice, Dstatus, DSelectedProduct;
    private String DAmande_gout_orange, DPistache_beldi, DAmande_kaab_ghzal, DPraliné, Dcafe, DCaramel_beurre_salé, DAmande_gingembre, DAmande_Orange, Damande_Rose, Dcaramel_chocolate, Dframboise, DGingember_citron_Vert, DCitron, DAmande_gout_rose, DSpeculos, DTruffe, DPistache, DNoix_de_coco;

    private void inputData() {
        DPraliné = Pralinéet.getText().toString().trim();
        Dcafe = caféet.getText().toString().trim();
        DCaramel_beurre_salé = Caramel_beurre_saléet.getText().toString().trim();
        DAmande_gout_orange = Amande_gout_orangeet.getText().toString().trim();
        DAmande_kaab_ghzal = Amande_kaab_ghzalet.getText().toString().trim();
        DPistache_beldi = Pistache_beldiet.getText().toString().trim();
        DAmande_gingembre = Amande_gingembreet.getText().toString().trim();
        DAmande_Orange = Amande_Orangeet.getText().toString().trim();
        Damande_Rose = amande_Roseet.getText().toString().trim();
        Dcaramel_chocolate = caramel_chocolateet.getText().toString().trim();
        Dframboise = framboiseet.getText().toString().trim();
        DGingember_citron_Vert = Gingember_citron_Vertet.getText().toString().trim();
        DCitron = Citronet.getText().toString().trim();
        DAmande_gout_rose = Amande_gout_roseet.getText().toString().trim();
        DSpeculos = Speculoset.getText().toString().trim();
        DNoix_de_coco = Noix_de_cocoet.getText().toString().trim();
        DTruffe = Truffeet.getText().toString().trim();
        DPistache = Pistacheet.getText().toString().trim();
        Dname = nameET.getText().toString().trim();
        Daddress = addresset.getText().toString().trim();
        Dphone = phoneet.getText().toString().trim();
        Dtime = timeet.getText().toString().trim();
        DSelectedProduct = SelectedProduct.trim();
        Ddetail = detailet.getText().toString().trim();
        Dstatus = status;
        Dprice = priceet.getText().toString().trim();


        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (DCaramel_beurre_salé.equals("")) {
                    Caramel_beurre_saléet.setText("0");
                }
                if (DPraliné.equals("")) {
                    Pralinéet.setText("0");
                }
                if (Dcafe.equals("")) {
                    caféet.setText("0");
                }
                if (DTruffe.equals("")) {
                    Truffeet.setText("0");
                }
                if (DPistache.equals("")) {
                    Pistacheet.setText("0");
                }
                if (DNoix_de_coco.equals("")) {
                    Noix_de_cocoet.setText("0");
                }
                if (DSpeculos.equals("")) {
                    Speculoset.setText("0");
                }
                if (DAmande_gout_rose.equals("")) {
                    Amande_gout_roseet.setText("0");
                }
                if (DCitron.equals("")) {
                    Citronet.setText("0");
                }
                if (DGingember_citron_Vert.equals("")) {
                    Gingember_citron_Vertet.setText("0");
                }
                if (Dframboise.equals("")) {
                    framboiseet.setText("0");
                }
                if (Dcaramel_chocolate.equals("")) {
                    caramel_chocolateet.setText("0");
                }
                if (DPistache_beldi.equals("")) {
                    Pistache_beldiet.setText("0");
                }
                if (Damande_Rose.equals("")) {
                    amande_Roseet.setText("0");
                }
                if (DAmande_Orange.equals("")) {
                    Amande_Orangeet.setText("0");
                }
                if (DAmande_gingembre.equals("")) {
                    Amande_gingembreet.setText("0");
                }
                if (DAmande_kaab_ghzal.equals("")) {
                    Amande_kaab_ghzalet.setText("0");
                }
                if (DAmande_gout_orange.equals("")) {
                    Amande_gout_orangeet.setText("0");
                }

                int total;
                int praline = Integer.parseInt(DPraliné);
                int caramel_val = Integer.parseInt(DCaramel_beurre_salé);
                int cafe_val = Integer.parseInt(Dcafe);
                int Truffe_val = Integer.parseInt(DTruffe);
                int Pistache_val = Integer.parseInt(DPistache);
                int Noix_de_coco_val = Integer.parseInt(DNoix_de_coco);
                int Speculos_val = Integer.parseInt(DSpeculos);
                int Amande_gout_rose_val = Integer.parseInt(DAmande_gout_rose);
                int Citron_val = Integer.parseInt(DCitron);
                int Gingember_citron_Vert_val = Integer.parseInt(DGingember_citron_Vert);
                int framboise_val = Integer.parseInt(Dframboise);
                int caramel_chocolate_val = Integer.parseInt(Dcaramel_chocolate);
                int amande_Rose_val = Integer.parseInt(Damande_Rose);
                int Amande_Orange_val = Integer.parseInt(DAmande_Orange);
                int Amande_gingembre_val = Integer.parseInt(DAmande_gingembre);
                int Amande_kaab_ghzal_val = Integer.parseInt(DAmande_kaab_ghzal);
                int Pistache_beldi_val = Integer.parseInt(DPistache_beldi);
                int Amande_gout_orange_val = Integer.parseInt(DAmande_gout_orange);
                total = (praline + Amande_gout_orange_val + Pistache_beldi_val + Amande_kaab_ghzal_val + Amande_gingembre_val + Amande_Orange_val + amande_Rose_val + caramel_chocolate_val + framboise_val + Gingember_citron_Vert_val + Citron_val + Amande_gout_rose_val + Speculos_val + cafe_val + caramel_val + Truffe_val + Pistache_val + Noix_de_coco_val);

                total_tvet.setText(total + " piéce");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        //do not forget to add a flavor
        Pralinéet.addTextChangedListener(textWatcher);
        caféet.addTextChangedListener(textWatcher);
        Caramel_beurre_saléet.addTextChangedListener(textWatcher);
        Pistacheet.addTextChangedListener(textWatcher);
        Noix_de_cocoet.addTextChangedListener(textWatcher);
        Speculoset.addTextChangedListener(textWatcher);
        Amande_gout_roseet.addTextChangedListener(textWatcher);
        Citronet.addTextChangedListener(textWatcher);
        Gingember_citron_Vertet.addTextChangedListener(textWatcher);
        framboiseet.addTextChangedListener(textWatcher);
        caramel_chocolateet.addTextChangedListener(textWatcher);
        amande_Roseet.addTextChangedListener(textWatcher);
        Amande_Orangeet.addTextChangedListener(textWatcher);
        Amande_gingembreet.addTextChangedListener(textWatcher);
        Amande_kaab_ghzalet.addTextChangedListener(textWatcher);
        Pistache_beldiet.addTextChangedListener(textWatcher);
        Amande_gout_orangeet.addTextChangedListener(textWatcher);
        Truffeet.addTextChangedListener(textWatcher);
        updateCommande();
    }

    private void updateCommande() {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("name", "" + Dname);
        hashMap.put("address", "" + Daddress);
        hashMap.put("phone", "" + Dphone);
        hashMap.put("time", "" + Dtime);
        hashMap.put("product", "" + DSelectedProduct);
        hashMap.put("details", "" + Ddetail);
        hashMap.put("status", "" + Dstatus);
        hashMap.put("price", "" + Dprice);
        hashMap.put("café", "" + Dcafe);
        hashMap.put("praliné", "" + DPraliné);
        hashMap.put("Caramel_beurre_salé", "" + DCaramel_beurre_salé);
        hashMap.put("Pistache", "" + DPistache);
        hashMap.put("Noix_de_coco", "" + DNoix_de_coco);
        hashMap.put("Speculos", "" + DSpeculos);
        hashMap.put("Amande_gout_rose", "" + DAmande_gout_rose);
        hashMap.put("Citron", "" + DCitron);
        hashMap.put("Gingember_citron_Vert", "" + DGingember_citron_Vert);
        hashMap.put("framboise", "" + Dframboise);
        hashMap.put("caramel_chocolate", "" + Dcaramel_chocolate);
        hashMap.put("amande_Rose", "" + Damande_Rose);
        hashMap.put("Amande_Orange", "" + DAmande_Orange);
        hashMap.put("Amande_gingembre", "" + DAmande_gingembre);
        hashMap.put("Amande_kaab_ghzal", "" + DAmande_kaab_ghzal);
        hashMap.put("Pistache_beldi", "" + DPistache_beldi);
        hashMap.put("Amande_gout_orange", "" + DAmande_gout_orange);
        hashMap.put("Truffe", "" + DTruffe);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(commande.class.getSimpleName());
        reference.child(uid)
                .updateChildren(hashMap).addOnSuccessListener(unused -> {
                    Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> {
                    Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                });
    }

    private void showDateTimeDialog(TextInputEditText time) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("DD/MM/yyyy HH:mm");
                    time.setText(simpleDateFormat.format(calendar.getTime()));
                }
            };
            new TimePickerDialog(EditCommandeActivity2.this, timeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show();
        };
        new DatePickerDialog(EditCommandeActivity2.this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

}