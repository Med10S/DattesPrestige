package com.example.dattespretige;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class new_command extends AppCompatActivity {
    private String SelectedProduct;//to hold the value of selected product
    private final String status = "En attente";
    public Spinner ProductSpinner;
    public ArrayAdapter<CharSequence> ProductAdapter;
    public TextInputEditText name, address, phone, time;
    //declaration des saveurs
    public EditText detail,  price;
    public EditText Praliné,
            café,
            Caramel_beurre_salé,
            Truffe,Pistache,Noix_de_coco,Speculos,
            Amande_gout_rose,Amande_gout_orange,Citron,
            Gingember_citron_Vert,framboise,caramel_chocolate,
            amande_Rose,Amande_Orange,Amande_gingembre,Amande_kaab_ghzal,Pistache_beldi;
    public TextView total_tv;
    public AppCompatButton submit_btn;
    public boolean pop = true;
    public String PREFS_NAME;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_commande);
//declaration and use of the spinner
        ProductSpinner = findViewById(R.id.spinnerProduct);

        ProductAdapter = ArrayAdapter.createFromResource(this, R.array.array_Product, R.layout.spinner_layout);
        ProductAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ProductSpinner.setAdapter(ProductAdapter);
        ProductSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SelectedProduct = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        name = findViewById(R.id.textInputName);
        address = findViewById(R.id.textInputAddress);
        phone = findViewById(R.id.textInputphone);
        time = findViewById(R.id.textInputTime);
        price = findViewById(R.id.price_text);
        time.setInputType(InputType.TYPE_NULL);
        time.setOnClickListener(v -> {
            showDateTimeDialog(time);
        });
        detail = findViewById(R.id.details);
        submit_btn = findViewById(R.id.submit);
        total_tv = findViewById(R.id.total);


        //initialisation des saveurs
        Praliné = findViewById(R.id.Praliné_val);
        café = findViewById(R.id.Cafe_val);
        Caramel_beurre_salé = findViewById(R.id.Caramel_beurre_salé_val);
        Pistache = findViewById(R.id.Pistache_val);
        Noix_de_coco = findViewById(R.id.Noix_de_coco_val);
        Speculos = findViewById(R.id.Speculos_val);
        Amande_gout_rose = findViewById(R.id.Amande_gout_rose_val);
        Citron = findViewById(R.id.Citron_val);
        Gingember_citron_Vert = findViewById(R.id.Gingember_citron_Vert_val);
        framboise = findViewById(R.id.framboise_val);
        caramel_chocolate = findViewById(R.id.caramel_chocolate_val);
        amande_Rose = findViewById(R.id.amande_Rose_val);
        Amande_Orange = findViewById(R.id.Amande_Orange_val);
        Amande_gingembre = findViewById(R.id.Amande_gingembre_val);
        Amande_kaab_ghzal = findViewById(R.id.Amande_kaab_ghzal_val);
        Pistache_beldi = findViewById(R.id.Pistache_beldi_val);
        Amande_gout_orange = findViewById(R.id.Amande_gout_orange_val);
        Truffe = findViewById(R.id.Truffe_val);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                 if (Caramel_beurre_salé.getText().toString().equals("")) {
                    Caramel_beurre_salé.setText("0");
                }
                 if (Praliné.getText().toString().equals("")) {
                    Praliné.setText("0");
                }
                 if (café.getText().toString().equals("")) {
                    café.setText("0");
                }
                 if (Truffe.getText().toString().equals("")) {
                    Truffe.setText("0");
                }
                 if (Pistache.getText().toString().equals("")) {
                    Pistache.setText("0");
                }
                 if (Noix_de_coco.getText().toString().equals("")) {
                    Noix_de_coco.setText("0");
                }
                 if (Speculos.getText().toString().equals("")) {
                    Speculos.setText("0");
                }
                 if (Amande_gout_rose.getText().toString().equals("")) {
                    Amande_gout_rose.setText("0");
                }
                 if (Citron.getText().toString().equals("")) {
                    Citron.setText("0");
                }
                 if (Gingember_citron_Vert.getText().toString().equals("")) {
                    Gingember_citron_Vert.setText("0");
                }
                 if (framboise.getText().toString().equals("")) {
                    framboise.setText("0");
                }
                 if (caramel_chocolate.getText().toString().equals("")) {
                    caramel_chocolate.setText("0");
                }
                 if (Pistache_beldi.getText().toString().equals("")) {
                    Pistache_beldi.setText("0");
                }
                 if (amande_Rose.getText().toString().equals("")) {
                    amande_Rose.setText("0");
                }
                 if (Amande_Orange.getText().toString().equals("")) {
                    Amande_Orange.setText("0");
                }
                 if (Amande_gingembre.getText().toString().equals("")) {
                    Amande_gingembre.setText("0");
                }
                 if (Amande_kaab_ghzal.getText().toString().equals("")) {
                    Amande_kaab_ghzal.setText("0");
                }
                 if (Amande_gout_orange.getText().toString().equals("")) {
                    Amande_gout_orange.setText("0");
                }

                int total;
                int praline = Integer.parseInt(Praliné.getText().toString());
                int caramel_val = Integer.parseInt(Caramel_beurre_salé.getText().toString());
                int cafe_val = Integer.parseInt(café.getText().toString());
                int Truffe_val = Integer.parseInt(Truffe.getText().toString());
                int Pistache_val = Integer.parseInt(Pistache.getText().toString());
                int Noix_de_coco_val = Integer.parseInt(Noix_de_coco.getText().toString());
                int Speculos_val = Integer.parseInt(Speculos.getText().toString());
                int Amande_gout_rose_val = Integer.parseInt(Amande_gout_rose.getText().toString());
                int Citron_val = Integer.parseInt(Citron.getText().toString());
                int Gingember_citron_Vert_val = Integer.parseInt(Gingember_citron_Vert.getText().toString());
                int framboise_val = Integer.parseInt(framboise.getText().toString());
                int caramel_chocolate_val = Integer.parseInt(caramel_chocolate.getText().toString());
                int amande_Rose_val = Integer.parseInt(amande_Rose.getText().toString());
                int Amande_Orange_val = Integer.parseInt(Amande_Orange.getText().toString());
                int Amande_gingembre_val = Integer.parseInt(Amande_gingembre.getText().toString());
                int Amande_kaab_ghzal_val = Integer.parseInt(Amande_kaab_ghzal.getText().toString());
                int Pistache_beldi_val = Integer.parseInt(Pistache_beldi.getText().toString());
                int Amande_gout_orange_val = Integer.parseInt(Amande_gout_orange.getText().toString());
                total = (
                        praline+
                        Amande_gout_orange_val+
                        Pistache_beldi_val+
                        Amande_kaab_ghzal_val+
                        Amande_gingembre_val+
                        Amande_Orange_val+
                        amande_Rose_val+
                        caramel_chocolate_val+
                        framboise_val+
                        Gingember_citron_Vert_val+
                        Citron_val+
                        Amande_gout_rose_val+
                        Speculos_val +
                        cafe_val + caramel_val+Truffe_val+Pistache_val+Noix_de_coco_val);

                total_tv.setText(total + " piéce");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
//do not forget to add a flavor
        Praliné.addTextChangedListener(textWatcher);
        café.addTextChangedListener(textWatcher);
        Caramel_beurre_salé.addTextChangedListener(textWatcher);
        Pistache.addTextChangedListener(textWatcher);
        Noix_de_coco.addTextChangedListener(textWatcher);
        Speculos.addTextChangedListener(textWatcher);
        Amande_gout_rose.addTextChangedListener(textWatcher);
        Citron.addTextChangedListener(textWatcher);
        Gingember_citron_Vert.addTextChangedListener(textWatcher);
        framboise.addTextChangedListener(textWatcher);
        caramel_chocolate.addTextChangedListener(textWatcher);
        amande_Rose.addTextChangedListener(textWatcher);
        Amande_Orange.addTextChangedListener(textWatcher);
        Amande_gingembre.addTextChangedListener(textWatcher);
        Amande_kaab_ghzal.addTextChangedListener(textWatcher);
        Pistache_beldi.addTextChangedListener(textWatcher);
        Amande_gout_orange.addTextChangedListener(textWatcher);
        Truffe.addTextChangedListener(textWatcher);

        submit_btn.setOnClickListener(v -> {
            addCommande();
        });


    }



    private String Dname, Daddress, Dphone, Dtime, Ddetail, Dprice, Dstatus, DSelectedProduct;
    private String DAmande_gout_orange, DPistache_beldi, DAmande_kaab_ghzal, DPraliné, Dcafe, DCaramel_beurre_salé, DAmande_gingembre, DAmande_Orange, Damande_Rose, Dcaramel_chocolate, Dframboise, DGingember_citron_Vert, DCitron, DAmande_gout_rose, DSpeculos , DTruffe, DPistache, DNoix_de_coco;
    private void addCommande() {
        DPraliné = Praliné.getText().toString().trim();
        Dcafe = café.getText().toString().trim();
        DCaramel_beurre_salé = Caramel_beurre_salé.getText().toString().trim();
        DAmande_gout_orange = Amande_gout_orange.getText().toString().trim();
        DAmande_kaab_ghzal = Amande_kaab_ghzal.getText().toString().trim();
        DPistache_beldi = Pistache_beldi.getText().toString().trim();
        DAmande_gingembre = Amande_gingembre.getText().toString().trim();
        DAmande_Orange = Amande_Orange.getText().toString().trim();
        Damande_Rose = amande_Rose.getText().toString().trim();
        Dcaramel_chocolate = caramel_chocolate.getText().toString().trim();
        Dframboise = framboise.getText().toString().trim();
        DGingember_citron_Vert = Gingember_citron_Vert.getText().toString().trim();
        DCitron = Citron.getText().toString().trim();
        DAmande_gout_rose = Amande_gout_rose.getText().toString().trim();
        DSpeculos = Speculos.getText().toString().trim();
        DNoix_de_coco = Noix_de_coco.getText().toString().trim();
        DTruffe = Truffe.getText().toString().trim();
        DPistache = Pistache.getText().toString().trim();

        Dname = name.getText().toString().trim();
        Daddress = address.getText().toString().trim();
        Dphone = phone.getText().toString().trim();
        Dtime = time.getText().toString().trim();
        DSelectedProduct = SelectedProduct.trim();
        Ddetail = detail.getText().toString().trim();




        Dstatus = status.toString().trim();
        Dprice = price.getText().toString().trim();
        String timstamp = "" + System.currentTimeMillis();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("id", "" + timstamp);
        hashMap.put("name", "" + Dname);
        hashMap.put("address", "" + Daddress);
        hashMap.put("phone", "" + Dphone);
        hashMap.put("time", "" + Dtime);
        hashMap.put("product", "" + DSelectedProduct);
        hashMap.put("details", "" + Ddetail);
        hashMap.put("status", "" + Dstatus);
        hashMap.put("price", "" + Dprice);
        hashMap.put("café", "" + Dcafe);
        hashMap.put("praliné", "" + DPraliné);
        hashMap.put("Caramel_beurre_salé", "" + DCaramel_beurre_salé);
        hashMap.put("Pistache", "" + DPistache);
        hashMap.put("Noix_de_coco", "" + DNoix_de_coco);
        hashMap.put("Speculos", "" + DSpeculos);
        hashMap.put("Amande_gout_rose", "" + DAmande_gout_rose);
        hashMap.put("Citron", "" + DCitron);
        hashMap.put("Gingember_citron_Vert", "" + DGingember_citron_Vert);
        hashMap.put("framboise", "" + Dframboise);
        hashMap.put("caramel_chocolate", "" + Dcaramel_chocolate);
        hashMap.put("amande_Rose", "" + Damande_Rose);
        hashMap.put("Amande_Orange", "" + DAmande_Orange);
        hashMap.put("Amande_gingembre", "" + DAmande_gingembre);
        hashMap.put("Amande_kaab_ghzal", "" + DAmande_kaab_ghzal);
        hashMap.put("Pistache_beldi", "" + DPistache_beldi);
        hashMap.put("Amande_gout_orange", "" + DAmande_gout_orange);
        hashMap.put("Truffe", "" + DTruffe);

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = db.getReference(commande.class.getSimpleName());
        databaseReference.push().setValue(hashMap).addOnSuccessListener(suc -> {
            Toast.makeText(this, "add with success", Toast.LENGTH_SHORT).show();




        }).addOnFailureListener(e -> {
            Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
        });

        Intent intent = new Intent(new_command.this, MainActivity.class);
        startActivity(intent);


    }

    private void showDateTimeDialog(TextInputEditText time) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("DD/MM/yyyy HH:mm");
                    time.setText(simpleDateFormat.format(calendar.getTime()));
                }
            };
            new TimePickerDialog(new_command.this, timeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show();
        };
        new DatePickerDialog(new_command.this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }


}