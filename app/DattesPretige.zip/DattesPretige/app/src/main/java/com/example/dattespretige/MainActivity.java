package com.example.dattespretige;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    /*-----------for navigation vue ---------------------*/
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    /*---------------------------------------------------*/
    RecyclerView recyclerView;
    RVadapter adapter;
    FloatingActionButton new_com;

    String Key = null;
    boolean isLoading = false;
    TextView filterCommandeTV,name_info;
    ImageButton filterOrderBtn;
    private  ArrayList<commande> commandeList,commandes;
    //private RVadapter rVadapter;
    private Button commencer;
    SwipeRefreshLayout swipeRefreshLayout;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*-----------for navigation vue ---------------------*/

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);
        /*--------------------Tool Bar-------------------------*/
        setSupportActionBar(toolbar);
        /*-----------------------Navigation Drawer Menu----------------------------*/
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_home);
        /*-------------------------------------------------------------------*/
        recyclerView = findViewById(R.id.rv);
        new_com = findViewById(R.id.add_btn_command);
        filterOrderBtn = findViewById(R.id.filterOrderBtn);
        filterCommandeTV = findViewById(R.id.filterCommandeTV);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        loadFilterCommande("en cours");


        SharedPreferences preferences = getSharedPreferences("PREFS",0);
        boolean isShowDialog = preferences.getBoolean("showDialog",true);
        if (isShowDialog){
            ShowDialog();
        }

        new_com.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, new_command.class);
            startActivity(intent);
        });
        //recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));
//        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
//            @Override
//            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
//                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
//                int totalItem = linearLayoutManager.getItemCount();
//                int lastVisible = linearLayoutManager.findLastCompletelyVisibleItemPosition();
//                if (totalItem < lastVisible + 1) {
//                    if (!isLoading) {
//                        isLoading = true;
//                        loadFilterCommande("en cours");
//                    }
//                }//2<
//            }
//        });
        filterOrderBtn.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Filter Commande")
                    .setItems(Constants.commandeStatus, (dialog, which) -> {
                        String selected = Constants.commandeStatus[which];
                        filterCommandeTV.setText(selected);
                        if (selected.equals("Showing All Order")){
                            loadData();
                        }
                        else{
                            loadFilterCommande(selected);
                        }
                    }).show();
        });

//        creatListOfData();
//        commencer=findViewById(R.id.commencer);
//        commencer.setOnClickListener(v->{
//            if (adapter.getSelected().size()>0){
//                StringBuilder stringBuilder = new StringBuilder();
//                for (int i =0 ;i< adapter.getSelected().size();i++){
//                    stringBuilder.append(adapter.getSelected().get(i).getName());
//                    stringBuilder.append("\n");
//                }
//                ShowToast(stringBuilder.toString().trim());
//            }else {
//                ShowToast("No selection");
//            }
//        });

    }
//    private void creatListOfData() {
//        for(int i = 0 ; i<20;i++){
//            commande com = new commande();
//            com.setName("client "+(i+1));
//            if (i == 0 ){
//                com.setChecked(true);
//            }
//            commandes.add(com);
//        }
//        adapter.setCommandes(commandes);
//    }
//    private void ShowToast(String msg){
//        Toast.makeText(this, "msg", Toast.LENGTH_SHORT).show();
//    }

    private void ShowDialog() {
        AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
        adb.setTitle("Information d'utilisation");
        adb.setMessage("les nouvelle commande sont par defaut mis en attente pour les voirs: \n ->cliquez sur le boutton filtre \n -> choisisez En attente \n\ncliquez sur Showwing all Order pour afficher tout les commandes");
        adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        adb.setNeutralButton ("Don't show again", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                SharedPreferences settings = getSharedPreferences("PREFS", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putBoolean("showDialog", false);
                // Commit the edits!
                editor.apply();
            }
        });
       AlertDialog alertDialog = adb.create();
       alertDialog.setCanceledOnTouchOutside(false);
       alertDialog.show();
    }

    private void loadFilterCommande(String selected) {
        commandeList = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(commande.class.getSimpleName());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                    commandeList.clear();

                for (DataSnapshot ds:snapshot.getChildren()){
                    String commandestatus = ""+ds.child("status").getValue();
                    if (selected.equals(commandestatus)){
                        commande com =ds.getValue(commande.class);
                        commandeList.add(com);
                    }

                }
                //setup the adapter
                adapter = new RVadapter(MainActivity.this,commandeList);
                //set adapter
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();

        }
    }

    private void loadData() {
        commandeList = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(commande.class.getSimpleName());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                commandeList.clear();
                for (DataSnapshot ds:snapshot.getChildren()){
                    commande com =ds.getValue(commande.class);
                    assert com != null;
                    commandeList.add(com);
                }
                //setup the adapter
                adapter = new RVadapter(MainActivity.this,commandeList);
                //set adapter
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
                break;
            case R.id.nav_new_commande:
                Intent intent = new Intent(MainActivity.this,new_command.class);
                startActivity(intent);
                break;
            case R.id.nav_Historique:
                Intent intent2 = new Intent(MainActivity.this,historique.class);
                startActivity(intent2);
                break;
            case R.id.nav_Stat:
                Intent intent3 = new Intent(MainActivity.this,statistique.class);
                startActivity(intent3);
                break;
            case R.id.nav_M_Premier:
                Intent intent4 = new Intent(MainActivity.this,Matiere_premier.class);
                startActivity(intent4);
                break;
            case R.id.nav_Guide:

                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("Guide");
                adb.setMessage("les nouvelle commande sont par defaut mis en attente pour les voirs: \n ->cliquez sur le boutton filtre \n -> choisisez En attente \n\ncliquez sur Showwing all Order pour afficher tout les commandes");
                adb.setPositiveButton("Ok", (dialog, which) -> dialog.dismiss());
                AlertDialog alertDialog = adb.create();
                alertDialog.show();

                break;

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}